// api/auth/[...nextauth]/route.ts
export { GET, POST } from "../../../../auth";
